<?php 

require('./src/Facebook/autoload.php');


$fb = new Facebook\Facebook([
  'app_id' => '654372022623546',
  'app_secret' => 'f7be15bc884685a3e816fa1702bd6373',
  'default_graph_version' => 'v2.10',
  ]);

  $data = [
    'message' => 'My awesome photo upload example.',
    'link' => 'http://www.example.com',
    'source' => $fb->fileToUpload('./src/Facebook-logo.png'),
  ];
  

try {
  // Returns a `Facebook\FacebookResponse` object
  $response = $fb->post('/me/photos', $data, 'EAAJTJdv1nToBAKo1yk8oJPG6XBZCrZAsylLhnq7zuxw4x38PwgNdjMZC4UjmhA4yKNxRzPcwyCDedzKleOe0Lo84BSKdpWhYTFoS1aMXqYxuZB6RmneZCwePh6CWBk5L7ZAo7DEsPR0haqqFo3Srn8J2QZBuCpZBAKu8MDblujnomBzZBQdZAWsG7Pl3w8q6cGHJfDzY1BhsMBcorWgby1qQKG');
} catch(Facebook\Exceptions\FacebookResponseException $e) {
  echo 'Graph returned an error: ' . $e->getMessage();
  exit;
} catch(Facebook\Exceptions\FacebookSDKException $e) {
  echo 'Facebook SDK returned an error: ' . $e->getMessage();
  exit;
}

$graphNode = $response->getGraphNode();

echo 'Posted with id: ' . $graphNode['id'];

?>