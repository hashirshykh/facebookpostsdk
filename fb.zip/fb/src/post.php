<?php 

require('./src/Facebook/autoload.php');


$fb = new Facebook\Facebook([
  'app_id' => '654372022623546',
  'app_secret' => 'f7be15bc884685a3e816fa1702bd6373',
  'default_graph_version' => 'v2.10',
  ]);

$linkData = [
  'link' => 'http://www.example.com',
  'message' => 'Post It ',
  ];

try {
  // Returns a `Facebook\FacebookResponse` object
  $response = $fb->post('/me/feed', $linkData, 'EAAJTJdv1nToBAHXMcZAWnUQI5Tn5Nm2EoM00hxT32hUGenjCuYGX0O4B1wZAbbdWJsZBn0dlThI92J29hsZABettZCjT37XuYmq4hKPZB1iQjcsVJD0a9QgBwTBAndy4UuEkY0wHcLAIgqy5y9HAbAXghNpiMVCwlkNR0JKVEDxF5ZAiaVZAPDOFvZBKb7SSiBmeIhKk3aXMnF0ZBxugDyRx7J');
} catch(Facebook\Exceptions\FacebookResponseException $e) {
  echo 'Graph returned an error: ' . $e->getMessage();
  exit;
} catch(Facebook\Exceptions\FacebookSDKException $e) {
  echo 'Facebook SDK returned an error: ' . $e->getMessage();
  exit;
}

$graphNode = $response->getGraphNode();

echo 'Posted with id: ' . $graphNode['id'];

?>